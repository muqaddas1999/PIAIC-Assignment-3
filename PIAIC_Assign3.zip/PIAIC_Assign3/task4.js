var cityNames = ["Islamabad" , "Karachi" , "Lahore" , "Peshawar" , "Quetta" , "Multan"];
document.write("<b>" + "Cities List:" + "</b>" + "<br>" + cityNames + "<br>" + "<br>");
var SCNames = cityNames.slice(3 , 6);
document.write("<b>" + "Selected Cities List:" + "</b>" + "<br>" + SCNames);