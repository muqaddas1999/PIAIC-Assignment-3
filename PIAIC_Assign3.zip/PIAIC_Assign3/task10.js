var A = [20,53,78,4,91,12];
document.write(A.sort((a,b) => a-b));