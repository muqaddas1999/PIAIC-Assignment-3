var arr1 = [3, 'a', 'a', 'a', 2, 3, 'a', 3, 'a', 2, 4, 9, 3] , arr2 = [...new Set(arr1)];
document.write(arr2);