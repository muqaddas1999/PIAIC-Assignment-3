var A = [24, 53, 78, 91, 12] , lg = Math.max(...A);
document.write("<b>" + "Array items: " + A + "<br>" + "The largest number is " + lg + "</b>");